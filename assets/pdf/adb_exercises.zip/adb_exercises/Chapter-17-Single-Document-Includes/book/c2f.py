# This converts Temperature in Celsius to Temperature in Fahrenhiet

#1 Get temperature in Celsius from user
celsius = float(input("Enter temperature in Celsius: "))

#2 Function Celsius to Fahrenheit
def c2f(c):
 f=c*1.8+32
 return f 

#3 Call the Function
fahrenheit=c2f(celsius)

#4 Print the result
print(f"{celsius}°C is equal to {fahrenheit}°F")
